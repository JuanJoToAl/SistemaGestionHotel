package com.mycompany.sistemagestionhotel;

public enum EstadoHabitacion {
    DISPONIBLE,
    RESERVADA,
    OCUPADA,
    MANTENIMIENTO
}
