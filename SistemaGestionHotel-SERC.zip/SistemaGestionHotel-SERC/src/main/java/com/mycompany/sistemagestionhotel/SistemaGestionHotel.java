
package com.mycompany.sistemagestionhotel;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.nio.file.*;
import java.io.IOException;

public class SistemaGestionHotel {
    private Hotel hotel;
    private List<Cliente> clientes;
    private Administrador administrador;
    private List<Reserva> reservas;
    private List<Factura> facturas;
    private int nextClienteId = 1;
    private int nextReservaId = 1;
    private int nextFacturaId = 1;

    // Constructor principal del sistema
    public SistemaGestionHotel() {
        this.clientes = new ArrayList<>();
        this.reservas = new ArrayList<>();
        this.facturas = new ArrayList<>();
        this.administrador = new Administrador("admin", "admin123");

        if (!cargarDatos()) {
            inicializarSistema();
        }
    }

    public static void main(String[] args) {
        SistemaGestionHotel sistema = new SistemaGestionHotel();
        sistema.mostrarMenuConsola();
    }

    private void inicializarSistema() {
        // Crear hotel con datos básicos
        this.hotel = new Hotel("Hotel Paradise", "Calle Principal 123", "+57 1 2345678");
        
        // Agregar habitaciones de diferentes tipos
        agregarHabitacionesPrueba();
        
        // Agregar algunos clientes de prueba
        agregarClientesPrueba();
    }

    private void agregarHabitacionesPrueba() {
        hotel.agregarHabitacion(new Habitacion(101, "Individual", 100000, EstadoHabitacion.DISPONIBLE));
        hotel.agregarHabitacion(new Habitacion(102, "Individual", 100000, EstadoHabitacion.DISPONIBLE));
        hotel.agregarHabitacion(new Habitacion(103, "Doble", 150000, EstadoHabitacion.DISPONIBLE));
        hotel.agregarHabitacion(new Habitacion(104, "Doble", 150000, EstadoHabitacion.DISPONIBLE));
        hotel.agregarHabitacion(new Habitacion(201, "Suite", 300000, EstadoHabitacion.DISPONIBLE));
        hotel.agregarHabitacion(new Habitacion(202, "Suite", 300000, EstadoHabitacion.DISPONIBLE));
        hotel.agregarHabitacion(new Habitacion(301, "Presidencial", 500000, EstadoHabitacion.DISPONIBLE));
    }

    private void agregarClientesPrueba() {
        // El ID real se asigna en registrarCliente, por eso usamos 0 como valor inicial.
        registrarCliente(new Cliente(0, "Juan Pérez", "12345678", "juan@email.com", "3001234567"));
        registrarCliente(new Cliente(0, "María García", "87654321", "maria@email.com", "3007654321"));
        registrarCliente(new Cliente(0, "Carlos López", "11223344", "carlos@email.com", "3001122334"));
    }

    // ===== MÉTODOS PRINCIPALES DEL SISTEMA =====

    public List<Habitacion> buscarHabitacionesDisponibles(LocalDate fechaInicio, LocalDate fechaFin) {
        // Usamos TODAS las habitaciones del hotel y decidimos la disponibilidad
        //  fanicamente seg fan las reservas existentes (no seg fan el estado actual de la habitaci f3n).
        List<Habitacion> todasHabitaciones = hotel.getHabitaciones();

        // Filtrar habitaciones que no tienen reservas conflictivas en las fechas solicitadas
        return todasHabitaciones.stream()
                .filter(habitacion -> estaDisponibleEnFechas(habitacion, fechaInicio, fechaFin))
                .collect(Collectors.toList());
    }

    private boolean estaDisponibleEnFechas(Habitacion habitacion, LocalDate fechaInicio, LocalDate fechaFin) {
        return reservas.stream()
                .noneMatch(reserva ->
                        reserva.getHabitacion().equals(habitacion)
                                && reserva.getEstado() != EstadoReserva.CANCELADA
                                && reserva.getEstado() != EstadoReserva.FINALIZADA
                                && reservasSeSuperponen(
                                        reserva.getFechaInicio(), reserva.getFechaFin(),
                                        fechaInicio, fechaFin
                                )
                );
    }

    private boolean reservasSeSuperponen(LocalDate inicio1, LocalDate fin1, LocalDate inicio2, LocalDate fin2) {
        return !(fin1.isBefore(inicio2) || inicio1.isAfter(fin2));
    }

    public Reserva realizarReserva(Cliente cliente, Habitacion habitacion, LocalDate fechaInicio, LocalDate fechaFin) {
        LocalDate hoy = LocalDate.now();

        if (fechaInicio.isBefore(hoy)) {
            throw new IllegalArgumentException("La fecha de inicio de la reserva no puede estar en el pasado");
        }
        if (fechaFin.isBefore(fechaInicio)) {
            throw new IllegalArgumentException("La fecha de fin no puede ser anterior a la fecha de inicio");
        }

        if (!habitacion.estaDisponible()) {
            throw new IllegalStateException("La habitación no está disponible (no está en estado DISPONIBLE)");
        }

        if (!estaDisponibleEnFechas(habitacion, fechaInicio, fechaFin)) {
            throw new IllegalStateException("La habitación no está disponible en las fechas seleccionadas");
        }

        Reserva reserva = new Reserva(nextReservaId++, fechaInicio, fechaFin, EstadoReserva.CONFIRMADA,
                                    habitacion, cliente.getCedula(), "Tarjeta");
        reservas.add(reserva);

        habitacion.setEstado(EstadoHabitacion.RESERVADA);

        return reserva;
    }

    public Factura generarFactura(Reserva reserva) {
        double subtotal = reserva.calcularTotal();

        Factura factura = new Factura(nextFacturaId++, LocalDate.now(), subtotal, 0, 0,
                                    reserva.getMetodoPago(), reserva);
        factura.calcularIVA(0.19); // 19% IVA
        facturas.add(factura);

        return factura;
    }

    public boolean realizarCheckIn(Reserva reserva, String cedula) {
        if (reserva == null) {
            return false;
        }

        if (reserva.getEstado() == EstadoReserva.CANCELADA ||
            reserva.getEstado() == EstadoReserva.CHECK_IN_REALIZADO ||
            reserva.getEstado() == EstadoReserva.FINALIZADA) {
            return false;
        }

        if (!reserva.getCedulaCheckIn().equals(cedula)) {
            return false;
        }

        reserva.realizarCheckIn(cedula);
        reserva.getHabitacion().setEstado(EstadoHabitacion.OCUPADA);

        return true;
    }

    public boolean autenticarAdministrador(String usuario, String contraseña) {
        return administrador != null && 
               administrador.getUsuario().equals(usuario) && 
               administrador.getContraseña().equals(contraseña);
    }

    public void registrarCliente(Cliente cliente) {
        if (cliente == null) {
            throw new IllegalArgumentException("El cliente no puede ser null");
        }

        String nombre = cliente.getNombre() != null ? cliente.getNombre().trim() : "";
        String cedula = cliente.getCedula() != null ? cliente.getCedula().trim() : "";
        String email = cliente.getEmail() != null ? cliente.getEmail().trim() : "";
        String telefono = cliente.getTelefono() != null ? cliente.getTelefono().trim() : "";

        if (nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre del cliente es obligatorio");
        }
        if (cedula.isEmpty()) {
            throw new IllegalArgumentException("La cédula del cliente es obligatoria");
        }

        // Evitar clientes duplicados por cédula
        boolean yaExiste = clientes.stream()
                .anyMatch(c -> c.getCedula().equals(cedula));
        if (yaExiste) {
            throw new IllegalStateException("Ya existe un cliente registrado con esa cédula");
        }

        // Validación sencilla de email
        if (!email.isEmpty()) {
            if (!email.contains("@") || !email.contains(".")) {
                throw new IllegalArgumentException("El email del cliente no tiene un formato válido");
            }
        }

        // Validación sencilla de teléfono (solo dígitos)
        if (!telefono.isEmpty()) {
            if (!telefono.matches("\\d+")) {
                throw new IllegalArgumentException("El teléfono del cliente solo debe contener dígitos");
            }
        }

        cliente.setId(nextClienteId++);
        clientes.add(cliente);
    }

    // ===== MÉTODOS DE CONSULTA =====

    public Cliente buscarClientePorCedula(String cedula) {
        return clientes.stream()
                .filter(cliente -> cliente.getCedula().equals(cedula))
                .findFirst()
                .orElse(null);
    }

    public Reserva buscarReservaPorId(int id) {
        return reservas.stream()
                .filter(reserva -> reserva.getId() == id)
                .findFirst()
                .orElse(null);
    }

    public List<Reserva> getReservasPorCliente(String cedulaCliente) {
        return reservas.stream()
                .filter(reserva -> reserva.getCedulaCheckIn().equals(cedulaCliente))
                .collect(Collectors.toList());
    }

    // ===== MÉTODOS DE ADMINISTRACIÓN =====

    public void agregarHabitacion(Habitacion habitacion) {
        hotel.agregarHabitacion(habitacion);
    }

    public boolean actualizarPrecioHabitacion(int numeroHabitacion, double nuevoPrecio) {
        Habitacion habitacion = hotel.getHabitaciones().stream()
                .filter(h -> h.getNumero() == numeroHabitacion)
                .findFirst()
                .orElse(null);
        if (habitacion == null) {
            return false;
        }
        habitacion.setPrecio(nuevoPrecio);
        return true;
    }

    // ===== MÉTODOS DE UTILIDAD =====

    public void mostrarEstadoInicial() {
        System.out.println("=== SISTEMA DE GESTIÓN HOTELERA INICIALIZADO ===");
        System.out.println("Hotel: " + hotel.getNombre());
        System.out.println("Dirección: " + hotel.getDireccion());
        System.out.println("Teléfono: " + hotel.getTelefono());
        System.out.println("Habitaciones disponibles: " + hotel.getHabitacionesDisponibles().size());
        System.out.println("Clientes registrados: " + clientes.size());
        System.out.println("Reservas activas: " + reservas.size());
        System.out.println("=============================================");
    }

    public void limpiarDatosPrueba() {
        reservas.clear();
        facturas.clear();

        hotel.getHabitaciones().forEach(h -> h.setEstado(EstadoHabitacion.DISPONIBLE));
        System.out.println("Datos de prueba limpiados. Sistema listo para uso real.");
        guardarDatos();
    }

    /**
     * Realiza el check-out de una reserva: marca la reserva como FINALIZADA y
     * libera la habitación dejándola en estado DISPONIBLE.
     * @param idReserva id de la reserva a finalizar
     * @return true si se pudo realizar el check-out, false en caso contrario
     */
    public boolean realizarCheckOut(int idReserva) {
        Reserva reserva = buscarReservaPorId(idReserva);
        if (reserva == null) {
            return false;
        }
        if (reserva.getEstado() != EstadoReserva.CHECK_IN_REALIZADO) {
            // Solo se puede hacer check-out de reservas con check-in realizado
            return false;
        }
        reserva.realizarCheckOut();
        reserva.getHabitacion().setEstado(EstadoHabitacion.DISPONIBLE);
        return true;
    }

    public boolean cancelarReserva(int idReserva) {
        Reserva reserva = buscarReservaPorId(idReserva);
        if (reserva == null) {
            return false;
        }
        if (reserva.getEstado() == EstadoReserva.CHECK_IN_REALIZADO
                || reserva.getEstado() == EstadoReserva.FINALIZADA) {
            return false; // no se puede cancelar una reserva ya usada o finalizada
        }
        reserva.setEstado(EstadoReserva.CANCELADA);
        reserva.getHabitacion().setEstado(EstadoHabitacion.DISPONIBLE);
        return true;
    }

    // ===== INTERFAZ DE CONSOLA =====

    public void mostrarMenuConsola() {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("\n=== SISTEMA DE GESTIÓN HOTELERA ===");
            System.out.println("1. Ver estado del sistema");
            System.out.println("2. Registrar cliente");
            System.out.println("3. Buscar habitaciones disponibles");
            System.out.println("4. Crear reserva");
            System.out.println("5. Realizar check-in");
            System.out.println("6. Cancelar reserva");
            System.out.println("7. Limpiar datos de prueba");
            System.out.println("8. Ver clientes");
            System.out.println("9. Ver reservas");
            System.out.println("10. Ver facturas");
            System.out.println("11. Pagar factura");
            System.out.println("12. Realizar check-out");
            System.out.println("13. Modo administrador");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();
            try {
                switch (opcion) {
                    case "1":
                        mostrarEstadoInicial();
                        break;
                    case "2":
                        registrarClienteDesdeConsola(scanner);
                        break;
                    case "3":
                        buscarHabitacionesDesdeConsola(scanner);
                        break;
                    case "4":
                        crearReservaDesdeConsola(scanner);
                        break;
                    case "5":
                        realizarCheckInDesdeConsola(scanner);
                        break;
                    case "6":
                        cancelarReservaDesdeConsola(scanner);
                        break;
                    case "7":
                        limpiarDatosPrueba();
                        break;
                    case "8":
                        mostrarClientesDesdeConsola(scanner);
                        break;
                    case "9":
                        mostrarReservasDesdeConsola(scanner);
                        break;
                    case "10":
                        mostrarFacturasDesdeConsola(scanner);
                        break;
                    case "11":
                        pagarFacturaDesdeConsola(scanner);
                        break;
                    case "12":
                        realizarCheckOutDesdeConsola(scanner);
                        break;
                    case "13":
                        mostrarMenuAdministrador(scanner);
                        break;
                    case "0":
                        guardarDatos();
                        salir = true;
                        break;
                    default:
                        System.out.println("Opción no válida.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void registrarClienteDesdeConsola(Scanner scanner) {
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("C e9dula: ");
        String cedula = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Tel e9fono: ");
        String telefono = scanner.nextLine();

        // Creamos el cliente con ID 0 y dejamos que registrarCliente asigne el ID real.
        Cliente cliente = new Cliente(0, nombre, cedula, email, telefono);
        registrarCliente(cliente);
        System.out.println("Cliente registrado con ID " + cliente.getId());
    }

    private void mostrarClientesDesdeConsola(Scanner scanner) {
        mostrarListaPaginada(getClientes(), 10,
                c -> "ID " + c.getId() + " - " + c.getNombre() + " (" + c.getCedula() + ")",
                scanner);
    }

    private void buscarHabitacionesDesdeConsola(Scanner scanner) {
        LocalDate inicio = leerFecha(scanner, "Fecha inicio (YYYY-MM-DD): ");
        LocalDate fin = leerFecha(scanner, "Fecha fin (YYYY-MM-DD): ");

        LocalDate hoy = LocalDate.now();
        if (inicio.isBefore(hoy)) {
            System.out.println("La fecha de inicio no puede estar en el pasado.");
            return;
        }
        if (fin.isBefore(inicio)) {
            System.out.println("La fecha de fin no puede ser anterior a la fecha de inicio.");
            return;
        }

        List<Habitacion> disponibles = buscarHabitacionesDisponibles(inicio, fin);
        if (disponibles.isEmpty()) {
            System.out.println("No hay habitaciones disponibles en ese rango.");
        } else {
            System.out.println("Habitaciones disponibles:");
            mostrarListaPaginada(disponibles, 10,
                    h -> "Hab. " + h.getNumero() + " (" + h.getEstado() + ") - Precio: " + h.getPrecio(),
                    scanner);
        }
    }

    private void crearReservaDesdeConsola(Scanner scanner) {
        System.out.print("Cédula del cliente: ");
        String cedula = scanner.nextLine();
        Cliente cliente = buscarClientePorCedula(cedula);
        if (cliente == null) {
            System.out.println("No existe cliente con esa cédula.");
            return;
        }

        LocalDate inicio = leerFecha(scanner, "Fecha inicio (YYYY-MM-DD): ");
        LocalDate fin = leerFecha(scanner, "Fecha fin (YYYY-MM-DD): ");

        LocalDate hoy = LocalDate.now();
        if (inicio.isBefore(hoy)) {
            System.out.println("La fecha de inicio no puede estar en el pasado.");
            return;
        }
        if (fin.isBefore(inicio)) {
            System.out.println("La fecha de fin no puede ser anterior a la fecha de inicio.");
            return;
        }

        List<Habitacion> disponibles = buscarHabitacionesDisponibles(inicio, fin);
        if (disponibles.isEmpty()) {
            System.out.println("No hay habitaciones disponibles en ese rango.");
            return;
        }

        System.out.println("Seleccione número de habitación de la lista (0 para cancelar):");
        for (Habitacion h : disponibles) {
            System.out.println("- " + h.getNumero() + " - " + h.getPrecio());
        }
        System.out.print("Número: ");
        String numStr = scanner.nextLine();
        int numero;
        try {
            numero = Integer.parseInt(numStr);
        } catch (NumberFormatException e) {
            System.out.println("Número inválido.");
            return;
        }
        if (numero == 0) {
            System.out.println("Operación cancelada.");
            return;
        }

        Habitacion seleccionada = disponibles.stream()
                .filter(h -> h.getNumero() == numero)
                .findFirst()
                .orElse(null);
        if (seleccionada == null) {
            System.out.println("No se encontró esa habitación en las disponibles.");
            return;
        }

        Reserva reserva = realizarReserva(cliente, seleccionada, inicio, fin);
        Factura factura = generarFactura(reserva);
        System.out.println("Reserva creada con ID " + reserva.getId() + ". Factura ID " + factura.getId());
    }

    private void realizarCheckInDesdeConsola(Scanner scanner) {
        System.out.print("ID de la reserva (0 para cancelar): ");
        String idStr = scanner.nextLine();
        int id;
        try {
            id = Integer.parseInt(idStr);
        } catch (NumberFormatException e) {
            System.out.println("ID inválido.");
            return;
        }
        if (id == 0) {
            System.out.println("Operación cancelada.");
            return;
        }

        Reserva reserva = buscarReservaPorId(id);
        if (reserva == null) {
            System.out.println("No existe una reserva con ese ID.");
            return;
        }

        System.out.print("Cédula para check-in: ");
        String cedula = scanner.nextLine();
        if (realizarCheckIn(reserva, cedula)) {
            System.out.println("Check-in realizado correctamente.");
        } else {
            System.out.println("No se pudo realizar el check-in. Verifique datos y estado de la reserva.");
        }
    }

    private void cancelarReservaDesdeConsola(Scanner scanner) {
        System.out.print("ID de la reserva a cancelar (0 para cancelar): ");
        String idStr = scanner.nextLine();
        int id;
        try {
            id = Integer.parseInt(idStr);
        } catch (NumberFormatException e) {
            System.out.println("ID inválido.");
            return;
        }
        if (id == 0) {
            System.out.println("Operación cancelada.");
            return;
        }

        if (cancelarReserva(id)) {
            System.out.println("Reserva cancelada.");
        } else {
            System.out.println("No se pudo cancelar la reserva (no existe o ya tiene check-in).");
        }
    }

    private void mostrarReservasDesdeConsola(Scanner scanner) {
        mostrarListaPaginada(getReservas(), 10, r ->
                "Reserva " + r.getId() + " - Cliente: " + r.getCedulaCheckIn() +
                " - Habitación: " + r.getHabitacion().getNumero() +
                " - " + r.getFechaInicio() + " a " + r.getFechaFin() +
                " - Estado: " + r.getEstado(),
                scanner);
    }

    private void mostrarFacturasDesdeConsola(Scanner scanner) {
        mostrarListaPaginada(getFacturas(), 10, f ->
                "Factura " + f.getId() + " - Reserva: " + f.getReserva().getId() +
                " - Total: " + f.getTotal() +
                " - Estado: " + (f.estaPagada() ? "PAGADA" : "PENDIENTE"),
                scanner);
    }

    private void pagarFacturaDesdeConsola(Scanner scanner) {
        System.out.print("ID de la factura a pagar (0 para cancelar): ");
        String idStr = scanner.nextLine();
        int id;
        try {
            id = Integer.parseInt(idStr);
        } catch (NumberFormatException e) {
            System.out.println("ID inválido. Debe ser un número entero.");
            return;
        }
        if (id == 0) {
            System.out.println("Operación cancelada.");
            return;
        }

        Factura factura = facturas.stream()
                .filter(f -> f.getId() == id)
                .findFirst()
                .orElse(null);
        if (factura == null) {
            System.out.println("No existe una factura con ese ID.");
            return;
        }
        if (factura.estaPagada()) {
            System.out.println("La factura ya está pagada.");
            return;
        }
        factura.pagar();
        System.out.println("Factura marcada como PAGADA.");
    }

    private void realizarCheckOutDesdeConsola(Scanner scanner) {
        System.out.print("ID de la reserva para check-out (0 para cancelar): ");
        String idStr = scanner.nextLine();
        int id;
        try {
            id = Integer.parseInt(idStr);
        } catch (NumberFormatException e) {
            System.out.println("ID inválido. Debe ser un número entero.");
            return;
        }
        if (id == 0) {
            System.out.println("Operación cancelada.");
            return;
        }

        if (realizarCheckOut(id)) {
            System.out.println("Check-out realizado correctamente. La habitación ha quedado disponible.");
        } else {
            System.out.println("No se pudo realizar el check-out. Verifique el ID y que la reserva tenga check-in realizado.");
        }
    }

    private void mostrarMenuAdministrador(Scanner scanner) {
        if (!autenticarAdministradorDesdeConsola(scanner)) {
            System.out.println("Credenciales incorrectas.");
            return;
        }

        boolean salir = false;
        while (!salir) {
            System.out.println("\n=== MODO ADMINISTRADOR ===");
            System.out.println("1. Ver todas las habitaciones");
            System.out.println("2. Actualizar precio de una habitación");
            System.out.println("3. Poner habitación en mantenimiento");
            System.out.println("4. Marcar habitación como disponible");
            System.out.println("5. Ver facturas generadas");
            System.out.println("0. Volver");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();
            switch (opcion) {
                case "1":
                    mostrarListaPaginada(hotel.getHabitaciones(), 10,
                            h -> "Habitación " + h.getNumero() + " - Estado: " + h.getEstado() + " - Precio: " + h.getPrecio(),
                            scanner);
                    break;
                case "2":
                    // Mostrar habitaciones con estado y precio antes de pedir datos
                    mostrarListaPaginada(hotel.getHabitaciones(), 10,
                            h -> "Hab. " + h.getNumero() + " - Estado: " + h.getEstado() + " - Precio: " + h.getPrecio(),
                            scanner);

                    System.out.print("Número de habitación (0 para cancelar): ");
                    String numStr = scanner.nextLine();
                    if (numStr.trim().equals("0")) {
                        System.out.println("Operación cancelada.");
                        break;
                    }
                    System.out.print("Nuevo precio: ");
                    String precioStr = scanner.nextLine();
                    try {
                        int numero = Integer.parseInt(numStr);
                        double precio = Double.parseDouble(precioStr);
                        if (actualizarPrecioHabitacion(numero, precio)) {
                            System.out.println("Precio actualizado.");
                        } else {
                            System.out.println("No existe una habitación con ese número.");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Datos inválidos.");
                    }
                    break;
                case "3":
                    cambiarEstadoHabitacionDesdeConsola(scanner, EstadoHabitacion.MANTENIMIENTO);
                    break;
                case "4":
                    cambiarEstadoHabitacionDesdeConsola(scanner, EstadoHabitacion.DISPONIBLE);
                    break;
                case "5":
                    if (facturas.isEmpty()) {
                        System.out.println("No hay facturas generadas.");
                    } else {
                        mostrarListaPaginada(facturas, 10,
                                f -> "Factura " + f.getId()
                                        + " - Reserva: " + f.getReserva().getId()
                                        + " - Total: " + f.getTotal()
                                        + " - Estado: " + (f.estaPagada() ? "PAGADA" : "PENDIENTE"),
                                scanner);
                    }
                    break;
                case "0":
                    salir = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    private boolean autenticarAdministradorDesdeConsola(Scanner scanner) {
        System.out.print("Usuario administrador: ");
        String usuario = scanner.nextLine();
        System.out.print("Contraseña: ");
        String contrasena = scanner.nextLine();
        return autenticarAdministrador(usuario, contrasena);
    }

    private void cambiarEstadoHabitacionDesdeConsola(Scanner scanner, EstadoHabitacion nuevoEstado) {
        List<Habitacion> habitacionesObjetivo;
        if (nuevoEstado == EstadoHabitacion.DISPONIBLE) {
            // Mostrar habitaciones que NO están disponibles actualmente
            habitacionesObjetivo = hotel.getHabitaciones().stream()
                    .filter(h -> !h.estaDisponible())
                    .collect(Collectors.toList());
        } else {
            habitacionesObjetivo = hotel.getHabitaciones();
        }

        System.out.println("Habitaciones disponibles para cambiar estado:");
        mostrarListaPaginada(habitacionesObjetivo, 10,
                h -> "Hab. " + h.getNumero() + " - Estado: " + h.getEstado() + " - Precio: " + h.getPrecio(),
                scanner);

        System.out.print("Número de habitación (0 para cancelar): ");
        String numStr = scanner.nextLine();
        try {
            int numero = Integer.parseInt(numStr);
            if (numero == 0) {
                System.out.println("Operación cancelada.");
                return;
            }
            Habitacion habitacion = hotel.getHabitaciones().stream()
                    .filter(h -> h.getNumero() == numero)
                    .findFirst()
                    .orElse(null);
            if (habitacion == null) {
                System.out.println("No existe esa habitación.");
                return;
            }
            habitacion.setEstado(nuevoEstado);
            System.out.println("Estado de la habitación actualizado a " + nuevoEstado + ".");
        } catch (NumberFormatException e) {
            System.out.println("Número inválido.");
        }
    }

    private <T> void mostrarListaPaginada(List<T> items, int tamPagina, Function<T, String> formateador, Scanner scanner) {
        if (items == null || items.isEmpty()) {
            System.out.println("No hay elementos para mostrar.");
            return;
        }

        int total = items.size();
        int paginas = (total + tamPagina - 1) / tamPagina;
        int paginaActual = 1;

        while (true) {
            if (paginaActual < 1) paginaActual = 1;
            if (paginaActual > paginas) paginaActual = paginas;

            int desde = (paginaActual - 1) * tamPagina;
            int hasta = Math.min(desde + tamPagina, total);

            System.out.println("\nPágina " + paginaActual + " de " + paginas);
            for (int i = desde; i < hasta; i++) {
                System.out.println(formateador.apply(items.get(i)));
            }

            System.out.print("Ingrese número de página (1-" + paginas + ") o 0 para salir (Enter para salir): ");
            String entrada = scanner.nextLine().trim();
            if (entrada.isEmpty()) {
                // Enter vacío -> salir
                break;
            }
            try {
                int seleccion = Integer.parseInt(entrada);
                if (seleccion == 0) {
                    break; // salir
                }
                if (seleccion >= 1 && seleccion <= paginas) {
                    paginaActual = seleccion;
                } else {
                    System.out.println("Número de página fuera de rango.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Entrada inválida.");
            }
        }
    }

    private LocalDate leerFecha(Scanner scanner, String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = scanner.nextLine();
            try {
                return LocalDate.parse(texto);
            } catch (Exception e) {
                System.out.println("Formato inválido. Use YYYY-MM-DD.");
            }
        }
    }

    // ===== GETTERS PARA LA INTERFAZ GRÁFICA =====

    public Hotel getHotel() { return hotel; }
    public List<Cliente> getClientes() { return new ArrayList<>(clientes); }
    public List<Reserva> getReservas() { return new ArrayList<>(reservas); }
    public List<Factura> getFacturas() { return new ArrayList<>(facturas); }
    public Administrador getAdministrador() { return administrador; }

    // ===== PERSISTENCIA EN ARCHIVOS CSV =====

    private boolean cargarDatos() {
        try {
            Path base = Paths.get("datos");
            if (!Files.exists(base)) {
                return false;
            }

            Path pathClientes = base.resolve("clientes.csv");
            Path pathHabitaciones = base.resolve("habitaciones.csv");
            Path pathReservas = base.resolve("reservas.csv");
            Path pathFacturas = base.resolve("facturas.csv");

            if (!Files.exists(pathClientes) || !Files.exists(pathHabitaciones)) {
                return false;
            }

            // Hotel básico (nombre/dirección fijo) y habitaciones desde archivo
            this.hotel = new Hotel("Hotel Paradise", "Calle Principal 123", "+57 1 2345678");
            if (Files.exists(pathHabitaciones)) {
                for (String linea : Files.readAllLines(pathHabitaciones)) {
                    if (linea.trim().isEmpty()) continue;
                    Habitacion h = Habitacion.fromCsv(linea);
                    hotel.agregarHabitacion(h);
                }
            }

            // Clientes
            if (Files.exists(pathClientes)) {
                for (String linea : Files.readAllLines(pathClientes)) {
                    if (linea.trim().isEmpty()) continue;
                    Cliente c = Cliente.fromCsv(linea);
                    clientes.add(c);
                    nextClienteId = Math.max(nextClienteId, c.getId() + 1);
                }
            }

            // Reservas (requieren habitaciones ya cargadas)
            Map<Integer, Habitacion> mapaHab = new HashMap<>();
            for (Habitacion h : hotel.getHabitaciones()) {
                mapaHab.put(h.getNumero(), h);
            }
            if (Files.exists(pathReservas)) {
                for (String linea : Files.readAllLines(pathReservas)) {
                    if (linea.trim().isEmpty()) continue;
                    String[] p = linea.split(";");
                    int numHab = Integer.parseInt(p[4]);
                    Habitacion h = mapaHab.get(numHab);
                    if (h == null) continue;
                    Reserva r = Reserva.fromCsv(linea, h);
                    reservas.add(r);
                    nextReservaId = Math.max(nextReservaId, r.getId() + 1);
                }
            }

            // Facturas (requieren reservas ya cargadas)
            Map<Integer, Reserva> mapaRes = new HashMap<>();
            for (Reserva r : reservas) {
                mapaRes.put(r.getId(), r);
            }
            if (Files.exists(pathFacturas)) {
                for (String linea : Files.readAllLines(pathFacturas)) {
                    if (linea.trim().isEmpty()) continue;
                    String[] p = linea.split(";");
                    int idReserva = Integer.parseInt(p[6]);
                    Reserva r = mapaRes.get(idReserva);
                    if (r == null) continue;
                    Factura f = Factura.fromCsv(linea, r);
                    facturas.add(f);
                    nextFacturaId = Math.max(nextFacturaId, f.getId() + 1);
                }
            }

            return true;
        } catch (IOException | RuntimeException e) {
            System.out.println("No se pudieron cargar datos: " + e.getMessage());
            return false;
        }
    }

    private void guardarDatos() {
        try {
            Path base = Paths.get("datos");
            if (!Files.exists(base)) {
                Files.createDirectories(base);
            }

            Path pathClientes = base.resolve("clientes.csv");
            Path pathHabitaciones = base.resolve("habitaciones.csv");
            Path pathReservas = base.resolve("reservas.csv");
            Path pathFacturas = base.resolve("facturas.csv");

            List<String> lineasClientes = new ArrayList<>();
            for (Cliente c : clientes) {
                lineasClientes.add(c.toCsv());
            }
            Files.write(pathClientes, lineasClientes);

            List<String> lineasHabitaciones = new ArrayList<>();
            for (Habitacion h : hotel.getHabitaciones()) {
                lineasHabitaciones.add(h.toCsv());
            }
            Files.write(pathHabitaciones, lineasHabitaciones);

            List<String> lineasReservas = new ArrayList<>();
            for (Reserva r : reservas) {
                lineasReservas.add(r.toCsv());
            }
            Files.write(pathReservas, lineasReservas);

            List<String> lineasFacturas = new ArrayList<>();
            for (Factura f : facturas) {
                lineasFacturas.add(f.toCsv());
            }
            Files.write(pathFacturas, lineasFacturas);

        } catch (IOException e) {
            System.out.println("No se pudieron guardar los datos: " + e.getMessage());
        }
    }
}
