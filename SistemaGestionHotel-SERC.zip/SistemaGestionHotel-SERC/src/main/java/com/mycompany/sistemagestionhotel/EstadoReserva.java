package com.mycompany.sistemagestionhotel;

public enum EstadoReserva {
    PENDIENTE,
    CONFIRMADA,
    CHECK_IN_REALIZADO,
    CANCELADA,
    FINALIZADA
}
